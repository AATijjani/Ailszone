<?php
// config.php

// Site settings
define('SITE_NAME', 'Ailzone');
define('BASE_URL', 'http://localhost/ailzone/');

// Database settings
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ailzone_db');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
