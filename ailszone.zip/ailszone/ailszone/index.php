<?php
// index.php

include 'includes/db.php';
include 'includes/header.php';

// Redirect to the homepage
header("Location: pages/home.php");
exit();

include 'includes/footer.php';
?>

